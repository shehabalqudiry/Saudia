<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ExperienceInSaudiaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
