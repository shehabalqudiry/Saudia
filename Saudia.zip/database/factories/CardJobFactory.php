<?php

namespace Database\Factories;

use App\Models\CardJob;
use Illuminate\Database\Eloquent\Factories\Factory;

class CardJobFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CardJob::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
