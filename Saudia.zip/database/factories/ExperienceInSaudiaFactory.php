<?php

namespace Database\Factories;

use App\Models\ExperienceInSaudia;
use Illuminate\Database\Eloquent\Factories\Factory;

class ExperienceInSaudiaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ExperienceInSaudia::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
