<?php

namespace Database\Factories;

use App\Models\MilitaryServices;
use Illuminate\Database\Eloquent\Factories\Factory;

class MilitaryServicesFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = MilitaryServices::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
