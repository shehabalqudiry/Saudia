<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('father_name');
            $table->string('email');
            $table->string('third_name');
            $table->string('forth_name');
            $table->string('gendar');
            $table->date('birth_day');
            $table->string('birth_address');
            $table->string('phone');
            $table->string('national_number');
            $table->string('home_address');
            $table->string('work_address');
            $table->string('religion');
            $table->string('children');

            // $table->string('passport_number');
            $table->unsignedBigInteger('nationality_id');
            $table->unsignedBigInteger('city_id');
            $table->unsignedBigInteger('job_id');

            $table->timestamps();

            $table->foreign('nationality_id')->references('id')->on('nationalities')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('id')->on('cities')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('job_id')->references('id')->on('jobs')->onDelete('cascade')->onUpdate('cascade');
        });
    }


    public function down()
    {
        Schema::dropIfExists('users');
    }
}
