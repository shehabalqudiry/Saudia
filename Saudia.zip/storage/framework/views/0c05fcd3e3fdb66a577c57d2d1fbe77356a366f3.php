<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, Active 4 Web
        </div>
    </div>
</footer>
<?php /**PATH /home/shehabalqudiry/Desktop/Active4Web/Saudia/resources/views/layouts/footer.blade.php ENDPATH**/ ?>