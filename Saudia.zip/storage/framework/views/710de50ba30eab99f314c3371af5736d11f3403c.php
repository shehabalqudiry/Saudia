<div class="sidebar text-center font-bold" data-color="purple" data-background-color="white" data-image="">
    <div class="logo">
        <a class="simple-text logo-normal">
            <img src="<?php echo e(asset('assets/img/Logo.png')); ?>" width="170px">
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="material-icons"></i>
                    <p>الرئيسية</p>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                    <i class="material-icons"></i>
                    <p>صلاحيات المشرفين</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('admins.index')); ?>">
                    <i class="material-icons"></i>
                    <p>المشرفين</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('job-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('jobs.index')); ?>">
                    <i class="material-icons"></i>
                    <p>الوظائف</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('nationality-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('nationalities.index')); ?>">
                    <i class="material-icons"></i>
                    <p>الجنسيات</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('city-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('cities.index')); ?>">
                    <i class="material-icons"></i>
                    <p>المحافظات</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="material-icons"></i>
                    <p>المتقدمين</p>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('settings.edit', 1)); ?>">
                    <i class="material-icons"></i>
                    <p>الاعدادات</p>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/layouts/main-sidebar.blade.php ENDPATH**/ ?>