
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-12">
        <div class="card box-shadow-0 text-right">
            <div class="card-header">
                
                <h4 class="card-title mb-1">تعديل : <?php echo e($role->name); ?></h4>
            </div>
            <div class="card-body pt-0">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group row">
                        <div class="col-6">
                            <label for="inputName">الاسم</label>
                            <input type="text" class="form-control" id="inputName" name="name"
                                value="<?php echo e($role->name); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-12">
                            <label for="role">الصلاحيات</label>
                            <div class="row mb-2">
                                
                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 mb-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <label class="ckbox wd-16 mg-b-0">
                                                    <input name="permission[]"
                                                        <?php echo e(in_array($pr->id, $rolePermissions) ? 'checked' : ''); ?>

                                                        value="<?php echo e($pr->id); ?>" class="mg-0" type="checkbox"><span></span>
                                                </label>
                                            </div>
                                        </div>
                                        <input class="form-control bg-light" placeholder="<?php echo e($pr->display_name); ?>"
                                            type="text" readonly>
                                    </div><!-- input-group -->
                                </div><!-- col-4 -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0 mt-3 justify-content-end">
                        <div>
                            <button type="submit" class="btn btn-primary">تعديل الدور</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>