<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/jquery.repeater.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/core/bootstrap-material-design.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU"></script>
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Chartist JS -->
<script src="<?php echo e(asset('assets/js/plugins/chartist.min.js')); ?>"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('assets/js/plugins/bootstrap-notify.js')); ?>"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="<?php echo e(asset('assets/js/material-dashboard.min.js?v=2.1.2')); ?>" type="text/javascript"></script>

<script type="text/javascript">
    $(document).ready(function (){
        $('select[name="nationality_id"]').on('change', function(){
            var nationality_id = $(this).val();
            if (nationality_id) {
                $.ajax({
                    url: "<?php echo e(URL::to('get-cities')); ?>/" + nationality_id,
                    type: "GET",
                    dataType: "json",
                    success: function(data){
                        $('select[name="city_id"]').empty();
                        $.each(data, function(key, value){
                            $('select[name="city_id"]').append('<option value="' + key + '">' + value + '</option>');
                        })
                    },
                });
            } else {
                console.log("AJAX Load Not Work");
            };
        });
    });
</script>
<?php if(session()->has('success')): ?>
<script>
    $.notify({
        icon: "add_alert",
        message: "<?php echo e(session()->get('success')); ?>"

        }, {
        type: 'success',
        timer: 3000,
        placement: {
        from: 'top',
        align: 'right'
        }
        });
</script>
<?php endif; ?>
<script>
    $(document).ready(function () {
        $('.repeater').repeater();
    });
</script>
</body>

</html><?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/layouts/master2.blade.php ENDPATH**/ ?>