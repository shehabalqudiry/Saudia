
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="d-flex my-xl-auto right-content">
        <div class="pull-right">
            
            <a class="btn btn-success" href="<?php echo e(route('roles.create')); ?>"> إضافة دور جديد</a>
            
        </div>
    </div>
    <div class="col-xl-12">
        <div class="card">
            
            <div class="card-header pb-0">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title mg-b-0">أدوار المشرفين</h4>
                    <i class="mdi mdi-dots-horizontal text-gray"></i>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table mg-b-0 text-md-nowrap text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>مسمى الدور</th>
                                <th width="280px">اعدادات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                    <a class="btn btn-info" href="<?php echo e(route('roles.edit',$role->id)); ?>">تعديل</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                    <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="post"
                                        style="display:inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $roles->render(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>