<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row align-item-center">
        <div class="col-12">
            <h4 class="card-title text-center my-4" style="background: rgb(45, 180, 115); color: white">
                سجل دخولك لرؤية بياناتك</h4>
        </div>
            <form action="<?php echo e(route('login-user')); ?>">
                <div class="form-group">
                    <input type="text" class="form-control" name="national_number">
                </div>
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/login.blade.php ENDPATH**/ ?>