<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, Active 4 Web
        </div>
    </div>
</footer>
<?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/layouts/footer.blade.php ENDPATH**/ ?>