<?php $__env->startSection('content'); ?>
<div class="col-md-12 text-right">
    <div class="card card-plain">
        <div class="card-header card-header-success">
            <h4 class="card-title mt-0">المتقدمين</h4>
        </div>
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="">
                        <th>
                            #
                        </th>
                        <th>
                            الاسم
                        </th>
                        <th>
                            الرقم القومي
                        </th>
                        <th>
                            الوظيفة المتقدم لها
                        </th>
                        <th>
                            الهاتف
                        </th>
                        <th>
                            اعدادات
                        </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($loop->iteration); ?>

                            </td>
                            <td>
                                <?php echo e($user->first_name . ' ' . $user->father_name . ' ' . $user->third_name . ' ' . $user->last_name); ?>

                            </td>
                            <td>
                                <?php echo e($user->national_number); ?>

                            </td>
                            <td>
                                <?php echo e($user->spec_title . ' ' . $user->job->job_title); ?>

                            </td>
                            <td>
                                <?php echo e($user->phone); ?>

                            </td>
                            <td>
                                <!--<button type="button" class="btn btn-success" data-toggle="modal"-->
                                <!--    data-target="#edit_<?php echo e($user->id); ?>">-->
                                <!--    تعديل-->
                                <!--</button>-->
                                <button type="button" class="btn btn-danger" data-toggle="modal"
                                    data-target="#delete_<?php echo e($user->id); ?>">
                                    حذف
                                </button>
                            </td>
                        </tr>
                        <?php echo $__env->make('admin.users.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebProjects\laragon\www\Saudia\resources\views/admin/users/index.blade.php ENDPATH**/ ?>